# AVR_TEA5767
TEA5767 Library for AVR<br>
<br>
This is an AVR library for TEA5767. <br>
This library was only tested with ATmega128A so you may need to change UART & TWI codes<br>
if you're using diffent MCU from AVR family.
<br>
[Tutorial]<br>
https://blog.naver.com/eziya76/221278359585<br>
https://blog.naver.com/eziya76/221280558615<br>

