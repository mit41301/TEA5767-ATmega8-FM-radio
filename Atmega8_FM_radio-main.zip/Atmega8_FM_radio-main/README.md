# Atmega8 FM radio
Project description is available on my webiste: [FM radio](https://411568.github.io/projects/atmega_fm_radio/)


## Author
Krzysztof Sikora
Kraków, 01.2023
