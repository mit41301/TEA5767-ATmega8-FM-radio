#ifndef RADIO_CONFIG_H_INCLUDED
#define RADIO_CONFIG_H_INCLUDED

#include <stdint.h>

enum {
	CONFIG_MIN_VOLUME = 20,
	CONFIG_DEFAULT_VOLUME = 50,
	CONFIG_MAX_VOLUME = 70
};

struct Config
{
	uint16_t id;
	uint32_t frequency;
	uint8_t volume;
	uint16_t crc;
};

extern struct Config config;

void load_config(void);

void store_config(void);

#endif
