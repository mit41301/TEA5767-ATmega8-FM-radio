/** FM radio
	Built with WinAVR 20090313, avr-libc 1.6.6
	
	User interface: pushbuttons at PD2 and PD3 (connected to the GND), used internal pull-ups.
	Using internal 2 MHz oscillator (see makefile).
	Use external pullups (i.e. 3k9) at SDA and SCL.
*/
#include "TEA5767.h"
#include "uart.h"
#include "radio_config.h"
#include "hw_config.h"
#include "timer1.h"
#include <avr/io.h>
#include <avr/delay.h>
#include <avr/signal.h>			//obsluga przerwan
#include <avr/interrupt.h>		//funkcje powiazane z obsluga przerwan

#define LOCAL_DEBUG
#ifdef LOCAL_DEBUG
#define LOG(args) (printf("MAIN "), printf args)
#endif

//obsluga zdarzenia rownosci licznika i rejestru OCR1A (output compare)
SIGNAL(SIG_OUTPUT_COMPARE1A)
{
	PORTB &= ~(1<<PIN_PWM);				//wyzerowanie bitu 2 portu A (wyjscia PWM)
} 

//obsluga zdarzenia rownosci licznika i rejestru OCR1B
SIGNAL(SIG_OUTPUT_COMPARE1B)
{
	//wyzerowanie licznika
	TCNT1=0;	
	//ustawienie wyjscia PWM
	PORTB |= (1<<PIN_PWM);
}

void init(void)    
{
	DDRB = 0XFF;
	// /** \note set minimum volume at startup */
	PORTB = 0x00;
	
	/** \note PORTD: input pushbuttons */
	DDRD = 0B00000000;
	PORTD = 0XFF;
	
	DDRC = 0B00000000;
	PORTC = 0Xff;      

	//_delay_ms(100);
	

	/** \note SCL = F_CPU/(16 + 2*TWBR*Prescaler) */
    TWSR = 0;                         /* no prescaler */	
	/** \note TWBR should be 10 or higher if the TWI operates in Master mode. If TWBR is lower than
	10, the Master may produce an incorrect output on SDA and SCL for the reminder of the
	byte. The problem occurs when operating the TWI in Master mode, sending Start + SLA
	+ R/W to a Slave (a Slave does not need to be connected to the bus for the condition to
	happen). */
	TWBR = 12;
	TWCR = (1<<TWEN); 
#ifdef LOCAL_DEBUG	
	UART_Init();
#endif

	start_timer();					//uruchomienie timera 1
	sei();							//globalne zezwolenie na przerwania
}


int main(void)
{
	uint8_t config_changed = 0;
	uint8_t searching = 0;
	struct TEA5767_status status;
	uint8_t counter = 0;
	
	init();	
	
	LOG(("FM radio starting...\n"));	
	
	load_config();	
	
	TEA5767_init();
	TEA5767_tune(config.frequency);
	TEA5767_write();	
	
	_delay_ms(300);	
	
	set_timer_duty_cycle(config.volume);		
	
	while(1)
	{
		uint8_t pb_state = PIND;
		if (searching == 0)
		{
#if 1
			// auto search
			if ((pb_state & (1<<PIN_TUNE_DOWN)) == 0)
			{
				TEA5767_search(0);
				searching = 1;
				_delay_ms(500);
			}
			else if ((pb_state & (1<<PIN_TUNE_UP)) == 0)
			{
				TEA5767_search(1);		
				searching = 2;
				_delay_ms(500);
			}
#else
			// manual search
			if ((pb_state & (1<<PIN_TUNE_DOWN)) == 0)
			{
				config.frequency -= 50;
				if (config.frequency >= 87500UL)
				{
					TEA5767_tune(config.frequency);
					TEA5767_write();	
				}
				else
				{
					config.frequency = 87500UL;
				}
				config_changed = 1;
			}
			else if ((pb_state & (1<<PIN_TUNE_UP)) == 0)
			{
				config.frequency += 50;
				if (config.frequency <= 108000UL)
				{
					TEA5767_tune(config.frequency);
					TEA5767_write();	
				}
				else
				{
					config.frequency = 108000UL;
				}
				config_changed = 1;
			}			
#endif
			// wait for keys release
			while ((pb_state & (1<<PIN_TUNE_DOWN)) == 0 || (pb_state & (1<<PIN_TUNE_UP)) == 0)
			{
				pb_state = PIND;	
			}
		}
		else
		{
			if (counter % 20 == 0)
			{
				TEA5767_get_status(&status);
				if (status.ready)
				{
					if (status.band_limit)
					{
						if (searching == 1)
						{
							// searching down, wrap
							TEA5767_tune(108000UL);
							TEA5767_search(0);
						}
						else
						{
							// searching up, wrap
							TEA5767_tune(87500UL);
							TEA5767_search(1);
						}
						_delay_ms(500);	
					}
					else
					{
						searching = 0;
						TEA5767_exit_search();
						config_changed = 1;
					}
				}
			}
		}
		_delay_ms(20);	


		// volume control
		if ((pb_state & (1<<PIN_VOL_DOWN)) == 0)
		{
			if (config.volume > CONFIG_MIN_VOLUME)
			{
				config.volume -= 5;
				set_timer_duty_cycle(config.volume);
				config_changed = 1;
			}
			else
			{
				set_timer_duty_cycle(2);			
			}
			LOG(("Vol DOWN %d\n", config.volume));	
			_delay_ms(300);	
		}
		else if ((pb_state & (1<<PIN_VOL_UP)) == 0)
		{
			if (config.volume < CONFIG_MAX_VOLUME)
				config.volume += 5;
			LOG(("Vol UP %d\n", config.volume));			
			set_timer_duty_cycle(config.volume);			
			config_changed = 1;
			_delay_ms(300);	
		}
	#if 0
		// wait for keys release
		while ((pb_state & (1<<PIN_VOL_DOWN)) == 0 || (pb_state & (1<<PIN_VOL_UP)) == 0)
		{
			pb_state = PIND;	
		}
	#endif

		if (++counter == 200)
		{
			PORTB ^= 0x02;	
			counter = 0;
			TEA5767_get_status(&status);
			if (config_changed)
			{
				// limiting EEPROM write frequency
				config.frequency = status.frequency;
				config_changed = 0;
				store_config();
			}
		}
	}
}
