#ifndef HW_CONFIG_H
#define HW_CONFIG_H

/* pushbuttons */
#define PIN_TUNE_DOWN	2
#define PIN_TUNE_UP		3
#define PIN_VOL_DOWN	6
#define PIN_VOL_UP		7

/* PWM output for TDA7052A volume control */
#define PIN_PWM			2

#endif
